package com.pushnotifications.example.dinesh.basicdagger

import dagger.Module
import dagger.Provides

@Module
class WheelsModule {

    //to get rims object
    @Provides
    fun provideRims(): Rims {
        return Rims()
    }

    //whenever tires is called the dagger creates tires object and returns it
    @Provides
    fun provideTires(): Tires {
        var tires = Tires()
        tires.getTires()
        return tires
    }

    //now dagger created the rims and tires so we can use them in wheels
    @Provides
    fun provideWheels(rims: Rims,tires: Tires): Wheels {
         return Wheels(rims,tires)
    }


}