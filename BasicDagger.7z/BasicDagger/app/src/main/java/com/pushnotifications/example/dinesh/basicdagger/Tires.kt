package com.pushnotifications.example.dinesh.basicdagger

import android.util.Log

class Tires {

    fun getTires(){
        Log.d("Car-Tires", "Ok tires on the way")
    }
}