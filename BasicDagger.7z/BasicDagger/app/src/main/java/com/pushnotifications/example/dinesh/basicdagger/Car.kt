package com.pushnotifications.example.dinesh.basicdagger

import android.util.Log
import javax.inject.Inject


 class Car @Inject constructor(val engine: Engine,val wheels: Wheels) {

    var TAG: String = "Car"

    fun drive() {
        Log.d(TAG, "drive...")
    }

    //method Injection
    @Inject
    fun startCar(engine: Engine) {
        engine.StartCar()
    }
}