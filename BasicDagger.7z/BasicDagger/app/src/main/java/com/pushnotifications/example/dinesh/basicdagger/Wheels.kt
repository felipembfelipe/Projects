package com.pushnotifications.example.dinesh.basicdagger

class Wheels  constructor(val rims: Rims, val tires: Tires){

}