package com.pushnotifications.example.dinesh.basicdagger

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import javax.inject.Inject

class MainActivity : AppCompatActivity() {

    //to demo Inject
   var car:Car? = null
    @Inject set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val component = DaggerCarComponent.create()
        //to demo Inject
        component.inject(this)

        //to demo DI
        //car = Car(Engine(),Wheels())

        //to demo component injection
        //car = component.getCar()


        car!!.drive()

    }
}
