package com.pushnotifications.example.dinesh.basicdagger

import android.util.Log
import javax.inject.Inject

class Engine @Inject constructor(){

    fun StartCar(){
        Log.d("Car","Started")
    }
}