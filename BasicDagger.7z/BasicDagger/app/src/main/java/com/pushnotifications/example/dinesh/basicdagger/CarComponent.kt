package com.pushnotifications.example.dinesh.basicdagger

import dagger.Component

@Component (modules = [WheelsModule::class])
interface CarComponent {

    fun getCar(): Car

    fun inject(mainActivity: MainActivity)
}